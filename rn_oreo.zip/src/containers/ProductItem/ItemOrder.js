import React from 'react';
import {View} from 'react-native';
import {Text} from 'src/components';

const ItemOrder = () => {
  return (
    <View>
      <Text>ItemOrder</Text>
    </View>
  );
};

export default ItemOrder;
