import React from 'react';
import {View} from 'react-native';
import {Text} from 'src/components';

const ItemCart = () => {
  return (
    <View>
      <Text>ItemCart</Text>
    </View>
  );
};

export default ItemCart;
