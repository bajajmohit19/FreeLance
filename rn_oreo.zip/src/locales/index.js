import en from './en';
import ar from './ar';
import ku from './ku';

export default {
  en,
  ar,
  ku,
};
