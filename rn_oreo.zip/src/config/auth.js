export const GOOGLE_SIGN_IN_CONFIG = {
  webClientId:
    '297766130098-m68tu9o0b0kgoi5aut7k3mepd1lotbn3.apps.googleusercontent.com',
  offlineAccess: true,
};

export const SUPPORT_DIGITS_PLUGIN = false;
