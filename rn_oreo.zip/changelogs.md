v2.4.1
- Fixed: Crash on Refine button

v2.4.0
- chore: shimmer loading blogs
- chore: shimmer loading product in store detail
- chore: shimmer loading in vendor list
- chore: shimmer loading in products
- chore: revert layout products in home
- Chore: remove ItemSecondary in home to container/ProductItem
- Fixed: Show product variations
- Improved: Update tag id for send notification

v2.3.3
- Fixed: Can't update profile

v2.3.2
- Improved: get vendor in detail product

v2.3.1
- Fixed: get vendor in detail product

v2.3.0
- Improved: fetch category
- Improved: cached data
- Fixed: add variation product
- Fixed: crash go all blog
- Improved: Change language

v2.2.2
- Fixed: add product group
- Fixed: variation key 0
- Fixed: add variation product

v2.2.1
- Improved: App speed on Android
- Upgrade: Latest dependencies
- Fixed: Crash app when click to logo on home screen

v2.2.0
- Upgrade: React native 0.63.3
- Improved: Update quantity

v2.1.3
- Fixed: Crash app in refine screen

v2.1.2
- Fixed: Search query in filter screen

v2.1.1
- Fixed: layout product list in home
- Fixed: blog grid in home

v2.1.0
- Improved: CART REST API work with Mobile builder v1.1.4
- Chore: remove show error in home get product and vendor

v2.0.4
- Chore: go policy by in payment
- Fix: data vendor null
- Chore: set loading webview checkout
- Updated: translate file en.json

v2.0.3
- Updated: Splash screen for Android

v2.0.2
- Fixed: outstock in list product in store
- Fixed: add to cart with product variation

v2.0.1
- Fixed: Check phone in register and login SMS
- Fixed: Config Firebase for Android

v2.0.0
- Changed: Update React native v0.62.0
- Changed: Update React navigation v5.x.x
- Changed: Cart REST API for custom flow checkout
- Changed: Use Mobile-builder plugin instead rnlab-app-control
- Added: Support WCFM vendor plugin
- Improvement: Splash screen on Android
- Improvement: Cached config builder and categories
- Improvement: Colors style template
- Improvement: Checkout webview token expired
- Fixed: variations in product detail
- Fixed: Query search
- Fixed: Click item sort by in refine screen
